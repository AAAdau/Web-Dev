import { Component } from '@angular/core';

import { Product, products } from '../products';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  products = [...products];

  share(product: Product, app: string) {
    let shareURL = '';
    if (app === 'whatsapp') {
      shareURL = `whatsapp://send?text=Check out this product: ${product.name} - ${product.url}`;
    } else if (app === 'telegram') {
      shareURL = `tg://msg_url?url=${product.url}&text=Check out this product: ${product.name}`;
    }
    window.location.href = shareURL;
  }
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/