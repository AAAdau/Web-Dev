export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  url:string;
}

export const products = [
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
    url:'https://kaspi.kz/',
    id: 1,
    name: 'cosmetic',
    price: 7999,
    description: 'A large phone with one of the best screens',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 2,
    name: 'camera',
    price: 699,
    description: 'A great phone with one of the best cameras',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 3,
    name: 'clothes',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 4,
    name: 'tools',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 5,
    name: 'Phone',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 6,
    name: 'notebbook',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 6,
    name: 'notebbook',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 6,
    name: 'notebbook',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 6,
    name: 'notebbook',
    price: 299,
    description: '',
  },
  {
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h27/hde/80620062081054.png?format=gallery-medium',
      url:'https://kaspi.kz/',
    id: 6,
    name: 'notebbook',
    price: 299,
    description: '',
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
